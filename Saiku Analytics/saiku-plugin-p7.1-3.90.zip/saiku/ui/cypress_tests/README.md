# Saiku Analytics Tests

## Getting Started

### Run [Cypress.io](https://github.com/cypress-io/cypress)

In order to run it locally you'll need:

1. Install [NodeJS](https://nodejs.org/en/download/), if you don't have it yet.
2. Install local dependencies:

```
npm install
```

### How to use

```
npm run cypress:open
```
